package com.example.magneto.kotlindemo.bean

class NavModel {
    var image:Int=0
    var name:String?=null
}
