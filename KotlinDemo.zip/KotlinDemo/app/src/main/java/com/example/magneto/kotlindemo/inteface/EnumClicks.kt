package com.example.magneto.kotlindemo.inteface

enum class EnumClicks{
    CELL;
}